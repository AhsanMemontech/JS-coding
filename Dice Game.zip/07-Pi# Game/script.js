'use strict';
const rollDice = $('.btn--roll');
const hold = $('.btn--hold');
const newGame = $('.btn--new');
let diceImage = $('.dice');

diceImage.addClass('hidden');
let currentScore = 0;
let totalScoreP1 = 0;
let totalScoreP2 = 0;
let activePlayer = 0;

newGame.click(function () {
  $('.player--0').removeClass('player--winner');
  $('.player--1').removeClass('player--winner');
  diceImage.addClass('hidden');
  rollDice.show();
  hold.show();
  activePlayer = 0;
  totalScoreP1 = 0;
  totalScoreP2 = 0;
  currentScore = 0;
  $('#current--0').text(0);
  $('#score--0').text(0);
  $('#current--1').text(0);
  $('#score--1').text(0);
});

rollDice.click(function () {
  if (
    (totalScoreP1 >= 20 || totalScoreP2 < 20) &&
    (totalScoreP1 < 20 || totalScoreP2 >= 20)
  ) {
    diceImage.removeClass('hidden');
    let randomDiceRolled = Math.trunc(Math.random() * 6) + 1;
    currentScore += randomDiceRolled;
    $(`#current--${activePlayer}`).text(currentScore);
    diceImage.attr('src', `dice-${randomDiceRolled}.png`);
    if (randomDiceRolled == 1) {
      $(`#current--${activePlayer}`).text(0);
      currentScore = 0;
      if ($('.player--0').hasClass('player--active') && activePlayer == 0) {
        $('.player--0').removeClass('player--active');
        $('.player--1').addClass('player--active');
        activePlayer = 1;
      } else {
        $('.player--0').addClass('player--active');
        $('.player--1').removeClass('player--active');
        activePlayer = 0;
      }
    }
  }
});

hold.click(function () {
  if (currentScore != totalScoreP1 && currentScore !== 0) {
    if (activePlayer == 0) {
      totalScoreP1 += currentScore;
      $(`#score--${activePlayer}`).text(totalScoreP1);
    } else {
      totalScoreP2 += currentScore;
      $(`#score--${activePlayer}`).text(totalScoreP2);
    }
  }
  $(`#current--${activePlayer}`).text(0);
  currentScore = 0;

  if (totalScoreP1 >= 20 || totalScoreP2 >= 20) {
    $(`.player--${activePlayer}`).addClass('player--winner');
    diceImage.attr('src', `player-${activePlayer}.png`);
    rollDice.hide();
    hold.hide();
  }
});
