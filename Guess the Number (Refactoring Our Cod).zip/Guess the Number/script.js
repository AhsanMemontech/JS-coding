"use strict";
let secretNumber = Math.trunc(Math.random() * 20) + 1;
let score = Number($(".score").text());
let highScore = Number($(".highScore").text());

const message = function (message) {
  $(".message").text(message);
};

$(".again").click("click", function () {
  message("Yoo! Now you can play again");
  score = 20;
  $(".score").text(score);
  $(".secretNumber").text("?");
  $(".input").val("");
  $("body").css("background-color", "black");
});

$(".check").click("click", function () {
  let inputNumber = Number($(".input").val());

  if (!inputNumber || inputNumber === 0 || inputNumber > 20) {
    message("No Number! / Invalid Number");
  } else if (inputNumber === secretNumber) {
    $("body").css("background-color", "green");
    message("Correct!");
    $(".secretNumber").text(inputNumber);
    if (score > highScore) {
      highScore = score;
      $(".highScore").text(score);
    }
    secretNumber = Math.round(Math.random() * 20);
  } else if (inputNumber !== secretNumber) {
    if (score < 1) {
      message("No more chance! You can play again");
    } else {
      message(inputNumber > secretNumber ? "Too High!" : "Too Low!");
      score--;
      $(".score").text(score);
      $(".secretNumber").text("?");
    }
  }
});
