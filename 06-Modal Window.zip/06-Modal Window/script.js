'use strict';
const modal = $('.modal');
const overlay = $('.overlay');
const btncloseModal = $('.close-modal');
const btnsOpenModal = $('.show-modal');

for (let i = 0; i < btnsOpenModal.length; i++) {
  btnsOpenModal[i].addEventListener('click', function () {
    //console.log(btnsOpenModal[i].textContent);
    modal.removeClass('hidden');
    overlay.removeClass('hidden');
  });
}

const closeModal = function () {
  modal.addClass('hidden');
  overlay.addClass('hidden');
};

btncloseModal.click('click', closeModal);
overlay.click('click', closeModal);

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !modal.hasClass('hidden')) {
    closeModal();
  }
});
