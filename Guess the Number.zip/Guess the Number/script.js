console.log(document.querySelector(".number").textContent);
console.log(document.querySelector(".input").textContent);
